public class Challenge1 {
    public static void main(String[] args){
//  public static void main(String[] args) {  
        System.out.println("What is \"Hardware\"?");

        System.out.println("Press Enter key to continue...");
        try
        {
            System.in.read();
        }
        catch(Exception e)
        {}
        System.out.println("The part of the computer that you can kick.");

    }
}