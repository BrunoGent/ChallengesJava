public class Challenge1v2 {
        public static void main(String[] args){
            System.out.println("What is \"Hardware\"?");

            try {
                Thread.sleep(3000);
            }
            catch(InterruptedException e) {
            }

            System.out.println("The part of the computer that you can kick");

        }
}
